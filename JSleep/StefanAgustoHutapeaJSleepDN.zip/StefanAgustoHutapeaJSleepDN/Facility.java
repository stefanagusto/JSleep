package StefanAgustoHutapeaJSleepDN;


    //enum
    public enum Facility
    {
        WiFi, 
        Bathub,
        Balcony,
        AC,
        FitnessCenter,
        Refrigerator,
        Restaurant,
        SwimmingPool
    }
