package StefanAgustoHutapeaJSleepDN;

//enum
public enum Type
{
    REBATE, DISCOUNT
}